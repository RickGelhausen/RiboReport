awk '$2 == "irsom"' predictions.gff > irsom.gff
awk '$2 == "reparation"' predictions.gff > reparation.gff
awk '$2 == "ribotish"' predictions.gff > ribotish.gff
awk '$2 == "deepribo"' predictions.gff > deepribo.gff

awk '{print $1":"$4"-"$5}' gigi_novel.gff > lists/gigi_novel_labels.txt
awk '{print $1":"$4"-"$5}' gigi_known.gff > lists/gigi_known_labels.txt

bedtools intersect -a gigi_novel.gff -b irsom.gff -s  -r -f 0.9 -wa > irsom_overlap_novel.gff
bedtools intersect -a gigi_novel.gff -b reparation.gff -s  -r -f 0.9 -wa > reparation_overlap_novel.gff
bedtools intersect -a gigi_novel.gff -b ribotish.gff -s  -r -f 0.9 -wa > ribotish_overlap_novel.gff
bedtools intersect -a gigi_novel.gff -b deepribo.gff -s  -r -f 0.9 -wa > deepribo_overlap_novel.gff

awk '{print $1":"$4"-"$5}' irsom_overlap_novel.gff > lists/irsom_novel.txt
awk '{print $1":"$4"-"$5}' reparation_overlap_novel.gff > lists/reparation_novel.txt
awk '{print $1":"$4"-"$5}' ribotish_overlap_novel.gff > lists/ribotish_novel.txt
awk '{print $1":"$4"-"$5}' deepribo_overlap_novel.gff > lists/deepribo_novel.txt


bedtools intersect -a gigi_known.gff -b irsom.gff -s  -r -f 0.9 -wa > irsom_overlap_known.gff
bedtools intersect -a gigi_known.gff -b reparation.gff -s  -r -f 0.9 -wa > reparation_overlap_known.gff
bedtools intersect -a gigi_known.gff -b ribotish.gff -s  -r -f 0.9 -wa > ribotish_overlap_known.gff
bedtools intersect -a gigi_known.gff -b deepribo.gff -s  -r -f 0.9 -wa > deepribo_overlap_known.gff

awk '{print $1":"$4"-"$5}' irsom_overlap_known.gff > lists/irsom_known.txt
awk '{print $1":"$4"-"$5}' reparation_overlap_known.gff > lists/reparation_known.txt
awk '{print $1":"$4"-"$5}' ribotish_overlap_known.gff > lists/ribotish_known.txt
awk '{print $1":"$4"-"$5}' deepribo_overlap_known.gff > lists/deepribo_known.txt
